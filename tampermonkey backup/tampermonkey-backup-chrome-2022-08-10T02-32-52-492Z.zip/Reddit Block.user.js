// ==UserScript==
// @name         Reddit Block
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.reddit.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=reddit.com
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    let listDeletes = [
        "https://www.reddit.com/user/GingerCocktail/",
        "https://www.reddit.com/user/Devious_Adorei/",
        "https://www.reddit.com/user/GasShot4931/",
        "https://www.reddit.com/user/call_me_pup/",
        "https://www.reddit.com/user/sxottylaw/",
        "https://www.reddit.com/user/Nicolettek7/",
        "https://www.reddit.com/user/Ok-Pie4146/",
        "https://www.reddit.com/user/Samcanram/",
        "https://www.reddit.com/user/Immediate_Monitor_45/",
        "https://www.reddit.com/user/KinkyHole4u/",
        "https://www.reddit.com/user/mariekaleida/",
        "https://www.reddit.com/user/BeverlyRose-TX/",
        "https://www.reddit.com/user/pittiplatsch19/",
        "https://www.reddit.com/user/Revolutionary_Ad1417/",
        "https://www.reddit.com/user/MrsPetitexx/",
        "https://www.reddit.com/user/Gapingsandra/",
        "https://www.reddit.com/user/HotPinkSundae/",
        "https://www.reddit.com/user/Sexy-lady80/",
        "https://www.reddit.com/user/Cindy068/",
        "https://www.reddit.com/user/emberwhisper/",
        "https://www.reddit.com/user/RubyGordonSlut/",
        "https://www.reddit.com/user/lillyvig/",
        "https://www.reddit.com/user/bootyandthebeast021/",
        "https://www.reddit.com/user/chellyxcx/",
        "https://www.reddit.com/user/misscherry14/",
        "https://www.reddit.com/user/HornyLinaFox/",
        "https://www.reddit.com/user/Tonyb360/",
        "https://www.reddit.com/user/peachwitchprivate/",
        "https://www.reddit.com/user/lilmollybaddie/",
        "https://www.reddit.com/user/CeeAnna/",
        "https://www.reddit.com/user/horny_wetqueenslut/",
        "https://www.reddit.com/user/Time_Reporter_5225/",
        "https://www.reddit.com/user/peachwitchprivate/",
        "https://www.reddit.com/user/rose544/",
        "https://www.reddit.com/user/rikuakime/",
        "https://www.reddit.com/user/Biggyonz/",
        "https://www.reddit.com/user/darbatil/",
        "https://www.reddit.com/user/Tara_Incognito/",
        "https://www.reddit.com/user/satansvices/",
        "https://www.reddit.com/user/Scarlett__Ava/",
        "https://www.reddit.com/user/Fit-Discount853/",
        "https://www.reddit.com/user/VirginiaCuckCouple/",
        "https://www.reddit.com/user/Tara_Incognito/",
        "https://www.reddit.com/user/Tara_Incognito/",
        "https://www.reddit.com/user/Silly_Position4684/",
        "https://www.reddit.com/user/horny_wetqueenslut/",
        "https://www.reddit.com/user/wa-fist/",
        "https://www.reddit.com/user/Fistcouple69/",
        "https://www.reddit.com/user/Loveemloose/",
        "https://www.reddit.com/user/Intelligent-Peak-700/",
        "https://www.reddit.com/user/Zealousideal_Worth59/",
        "https://www.reddit.com/user/omen95100/",
        "https://www.reddit.com/user/elleSweetQueen/",
        "https://www.reddit.com/user/mmmolly_riot/",
        "https://www.reddit.com/user/MahoganyMel/",
        "https://www.reddit.com/user/Fearless_Status_4583/",
        "https://www.reddit.com/user/worthless_holes/",
        "https://www.reddit.com/user/Anthobbbll69/",
        "https://www.reddit.com/user/tannyboy0/",
        "https://www.reddit.com/user/Seathundergod/",
        "https://www.reddit.com/user/Stretchmeloose166/",
        "https://www.reddit.com/user/Flashy_Row_1389/",
        "https://www.reddit.com/user/winging_it23/",
        "https://www.reddit.com/user/redlily22_00/",
        "https://www.reddit.com/user/Silly_Intern_1820/",
        "https://www.reddit.com/user/PennyLayne999/",
        "https://www.reddit.com/user/TentacleBimbo/",
        "https://www.reddit.com/user/Rayssa_gapeslut/",
        "https://www.reddit.com/user/Janica99/",
        "https://www.reddit.com/user/Afternoon-Narrow/",
        "https://www.reddit.com/user/libra_1995/",
        "https://www.reddit.com/user/scrat9988/",
        "https://www.reddit.com/user/xyummiimilfx/",
        "https://www.reddit.com/user/hungryformore1/",
        "https://www.reddit.com/user/WayPuzzleheaded3109/",
        "https://www.reddit.com/user/theeuroslut/",
        "https://www.reddit.com/user/LucyLoosey1/",
        "https://www.reddit.com/user/ditafist/",
        "https://www.reddit.com/user/Dear_Zookeepergame85/",
        "https://www.reddit.com/user/Advanced_Nebula6850/",
        "https://www.reddit.com/user/Holelottolove/",
        "https://www.reddit.com/user/FillOk535/",
        "https://www.reddit.com/user/missjane87/",
        "https://www.reddit.com/user/lillianwet/",
        "https://www.reddit.com/user/Expert-Fig7868/",
        "https://www.reddit.com/user/Yinbebecita/",
        "https://www.reddit.com/user/Bbcnews6969/",
        "https://www.reddit.com/user/ColbyFlagi/",
        "https://www.reddit.com/user/rosie_alasia/",
        "https://www.reddit.com/user/KrazyRussianFun33/",
        "https://www.reddit.com/user/CeelCee/",
        "https://www.reddit.com/user/Teamplayax/",
        "https://www.reddit.com/user/Salt_Zebra_423/",
        "https://www.reddit.com/user/LRX19/",
        "https://www.reddit.com/user/unic0rnbab3/",
        "https://www.reddit.com/user/Kynng_Thot/",
        "https://www.reddit.com/user/submissive-freeuse/",
        "https://www.reddit.com/user/MagnoBorrowo/",
        "https://www.reddit.com/user/PageCompetitive9746/",
        "https://www.reddit.com/user/2manic4u/",
        "https://www.reddit.com/user/SexmonkeyScarlet/",
        "https://www.reddit.com/user/Mindless-Debate-2422/",
        "https://www.reddit.com/user/Sofieshh/",
        "https://www.reddit.com/user/slut19072/",
        "https://www.reddit.com/user/MoistRequirement3021/",
        "https://www.reddit.com/user/Aussiemilf2046/",
        "https://www.reddit.com/user/NoonWraithDance/",
        "https://www.reddit.com/user/thrown2thewolves53/",
        "https://www.reddit.com/user/chromegrill/",
        "https://www.reddit.com/user/Effective_Poetry_789/",
        "https://www.reddit.com/user/AlexaAdmireo",
        "https://www.reddit.com/user/Jilliebeans112",
        "https://www.reddit.com/user/Naughtycouple6969",
        "https://www.reddit.com/user/FarrahPFister",
        "https://www.reddit.com/user/Own_me10001",
        "https://www.reddit.com/user/WatercressJust770",
        "https://www.reddit.com/user/Euphoric-Beginning60",
        "https://www.reddit.com/user/dadbod980",
        "https://www.reddit.com/user/2missmae",
        "https://www.reddit.com/user/caprioworks",
        "https://www.reddit.com/user/bigw0r",
        "https://www.reddit.com/user/Economy-Programmer-7",
        "https://www.reddit.com/user/Majestic_Bad112",
        "https://www.reddit.com/user/openwetnwide",
        "https://www.reddit.com/user/gndownwife",
        "https://www.reddit.com/user/Pikabois",
        "https://www.reddit.com/user/FullWork0",
        "https://www.reddit.com/user/southrnchevyboy",
        "https://www.reddit.com/user/sk_sobaka555",
        "https://www.reddit.com/user/hot_gf1997",
        "https://www.reddit.com/user/Tattooedchef_4u",
        "https://www.reddit.com/user/chargabe_11",
        "https://www.reddit.com/user/BaylahB",
        "https://www.reddit.com/user/freakslutsage",
        "https://www.reddit.com/user/Diesel_gang24v",
        "https://www.reddit.com/user/dos_biscuits",
        "https://www.reddit.com/user/BaylahB",
        "https://www.reddit.com/user/Odd-Ad6334",
        "https://www.reddit.com/user/Skeltorsmokee",
        "https://www.reddit.com/user/ceded15",
        "https://www.reddit.com/user/sophiab63",
        "https://www.reddit.com/user/Browneyedbrat3",
        "https://www.reddit.com/user/No_Mention_4550",
        "https://www.reddit.com/user/Adventurous_Top_4492",
        "https://www.reddit.com/user/daydreamingprisoner-",
        "https://www.reddit.com/user/gapingwombs/",
        "https://www.reddit.com/user/PuffyPussyMilf/",
        "https://www.reddit.com/user/Swollencock89/",
        "https://www.reddit.com/user/softgirll/",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",

        // listDeletes
    ];


    let goodlist = [
        "https://www.reddit.com/user/L0v2Str3tch/",
        "https://www.reddit.com/user/LooseyGooseyEva/",
        "https://www.reddit.com/user/DLF21/",
        "https://www.reddit.com/user/VixenxMoon/",
        "https://www.reddit.com/user/crazywifeslut/",
        "https://www.reddit.com/user/Even-Aioli7876/",
        "https://www.reddit.com/user/HornyLinaFox/",
        "https://www.reddit.com/user/_joseywalesss/",
        "https://www.reddit.com/user/babymoonsun/",
        "https://www.reddit.com/user/Str3tchyness/",
        "https://www.reddit.com/user/justlooking_94/",
        "https://www.reddit.com/user/jocaladium/",
        "https://www.reddit.com/user/Maxeengreen/",
        "https://www.reddit.com/user/ShowOffCandy/",
        "https://www.reddit.com/user/sizeprincessnina/",
        "https://www.reddit.com/user/leaksfrommybedroom/",
        "https://www.reddit.com/user/SukiExploring/",
        "https://www.reddit.com/user/YourFavSlut21/",
        "https://www.reddit.com/user/Pusscakess/",
        "https://www.reddit.com/user/IBM--5100/",
        "https://www.reddit.com/user/RocheLimit9492/",
        "https://www.reddit.com/user/PunkdPrincess/",
        "https://www.reddit.com/user/loosepussyland",
        "https://www.reddit.com/user/Monika_Fox/",
        "https://www.reddit.com/user/SassyGirl-Ok",
        "https://www.reddit.com/user/OrangeMouse1250",
        "https://www.reddit.com/user/Ok_Dragonfly_666",
        "https://www.reddit.com/user/openpuss",
        "https://www.reddit.com/user/TheDawlMaker",
        "https://www.reddit.com/user/bigyoni95/",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        // goodlist
    ];



    listDeletes.push(...goodlist);


    function isContainUrl() {

        for (let i = 0; i < listDeletes.length; i++) {
            if (window.location.href.includes(listDeletes[i]) && (listDeletes[i]) != '') {
                return true;
            }
        }
        return false;
    }


    function urlSiteCrop(url) {
        let output = url.replace("https://www.reddit.com", "");
        return output;
    };


    function delBoxes() {
        if (isContainUrl()) {
            document.querySelector(`body`).remove();
            document.querySelector("html").style="background-color:aqua;";
            return;
        }

        let alllinks = document.querySelectorAll(`.rpBJOHq2PR60pnwJlUyP0 ._2mHuuvyV9doV3zwbZPtIPG a`);
        let linksinclude = [];

        alllinks.forEach((item) => {
            if (listDeletes.includes(item.href) || listDeletes.includes(item.href.replace(/\/$/,""))) {
                linksinclude.push(item);
            }
        });
        linksinclude.forEach(e=>e.closest('[data-testid="post-container"]').parentNode.parentNode.remove());
    }
    delBoxes();


    const observer1 = new MutationObserver(function (mutation) {
        mutation.forEach(function (mutation) {
            if (mutation.addedNodes.length) {
                delBoxes();
                console.log("хуй");
            }
        })
    });


    if (document.querySelector('.qYj03fU5CXf5t2Fc5iSvg.ListingLayout-outerContainer') != null) {
        const playlistWrapper1 = document.querySelector('.qYj03fU5CXf5t2Fc5iSvg.ListingLayout-outerContainer');
        observer1.observe(playlistWrapper1, {
            childList: true,
            //     attributes: true,
            subtree: true,
            //   characterData: true,
        })
    }

})();