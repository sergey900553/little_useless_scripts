// ==UserScript==
// @name         Old reddit
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://old.reddit.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=reddit.com
// @grant        none
// ==/UserScript==


(function () {
    'use strict';
    // document.querySelectorAll(`.rpBJOHq2PR60pnwJlUyP0 a`).forEach(e => e.closest('[data-testid="post-container"]').parentNode.parentNode.remove());

    let listDeletes = [
        "https://old.reddit.com/user/GingerCocktail/",
        "https://old.reddit.com/user/Devious_Adorei/",
        "https://old.reddit.com/user/GasShot4931/",
        "https://old.reddit.com/user/call_me_pup/",
        "https://old.reddit.com/user/sxottylaw/",
        "https://old.reddit.com/user/Nicolettek7/",
        "https://old.reddit.com/user/Ok-Pie4146/",
        "https://old.reddit.com/user/Samcanram/",
        "https://old.reddit.com/user/Immediate_Monitor_45/",
        "https://old.reddit.com/user/KinkyHole4u/",
        "https://old.reddit.com/user/mariekaleida/",
        "https://old.reddit.com/user/BeverlyRose-TX/",
        "https://old.reddit.com/user/pittiplatsch19/",
        "https://old.reddit.com/user/Revolutionary_Ad1417/",
        "https://old.reddit.com/user/MrsPetitexx/",
        "https://old.reddit.com/user/Gapingsandra/",
        "https://old.reddit.com/user/HotPinkSundae/",
        "https://old.reddit.com/user/Sexy-lady80/",
        "https://old.reddit.com/user/Cindy068/",
        "https://old.reddit.com/user/emberwhisper/",
        "https://old.reddit.com/user/RubyGordonSlut/",
        "https://old.reddit.com/user/lillyvig/",
        "https://old.reddit.com/user/bootyandthebeast021/",
        "https://old.reddit.com/user/chellyxcx/",
        "https://old.reddit.com/user/misscherry14/",
        "https://old.reddit.com/user/HornyLinaFox/",
        "https://old.reddit.com/user/Tonyb360/",
        "https://old.reddit.com/user/peachwitchprivate/",
        "https://old.reddit.com/user/lilmollybaddie/",
        "https://old.reddit.com/user/CeeAnna/",
        "https://old.reddit.com/user/horny_wetqueenslut/",
        "https://old.reddit.com/user/Time_Reporter_5225/",
        "https://old.reddit.com/user/peachwitchprivate/",
        "https://old.reddit.com/user/rose544/",
        "https://old.reddit.com/user/rikuakime/",
        "https://old.reddit.com/user/Biggyonz/",
        "https://old.reddit.com/user/darbatil/",
        "https://old.reddit.com/user/Tara_Incognito/",
        "https://old.reddit.com/user/satansvices/",
        "https://old.reddit.com/user/Scarlett__Ava/",
        "https://old.reddit.com/user/Fit-Discount853/",
        "https://old.reddit.com/user/VirginiaCuckCouple/",
        "https://old.reddit.com/user/Tara_Incognito/",
        "https://old.reddit.com/user/Tara_Incognito/",
        "https://old.reddit.com/user/Silly_Position4684/",
        "https://old.reddit.com/user/horny_wetqueenslut/",
        "https://old.reddit.com/user/wa-fist/",
        "https://old.reddit.com/user/Fistcouple69/",
        "https://old.reddit.com/user/Loveemloose/",
        "https://old.reddit.com/user/Intelligent-Peak-700/",
        "https://old.reddit.com/user/Zealousideal_Worth59/",
        "https://old.reddit.com/user/omen95100/",
        "https://old.reddit.com/user/elleSweetQueen/",
        "https://old.reddit.com/user/mmmolly_riot/",
        "https://old.reddit.com/user/MahoganyMel/",
        "https://old.reddit.com/user/Fearless_Status_4583/",
        "https://old.reddit.com/user/worthless_holes/",
        "https://old.reddit.com/user/Anthobbbll69/",
        "https://old.reddit.com/user/tannyboy0/",
        "https://old.reddit.com/user/Seathundergod/",
        "https://old.reddit.com/user/Stretchmeloose166/",
        "https://old.reddit.com/user/Flashy_Row_1389/",
        "https://old.reddit.com/user/winging_it23/",
        "https://old.reddit.com/user/redlily22_00/",
        "https://old.reddit.com/user/Silly_Intern_1820/",
        "https://old.reddit.com/user/PennyLayne999/",
        "https://old.reddit.com/user/TentacleBimbo/",
        "https://old.reddit.com/user/Rayssa_gapeslut/",
        "https://old.reddit.com/user/Janica99/",
        "https://old.reddit.com/user/Afternoon-Narrow/",
        "https://old.reddit.com/user/libra_1995/",
        "https://old.reddit.com/user/scrat9988/",
        "https://old.reddit.com/user/xyummiimilfx/",
        "https://old.reddit.com/user/hungryformore1/",
        "https://old.reddit.com/user/WayPuzzleheaded3109/",
        "https://old.reddit.com/user/theeuroslut/",
        "https://old.reddit.com/user/LucyLoosey1/",
        "https://old.reddit.com/user/ditafist/",
        "https://old.reddit.com/user/Dear_Zookeepergame85/",
        "https://old.reddit.com/user/Advanced_Nebula6850/",
        "https://old.reddit.com/user/Holelottolove/",
        "https://old.reddit.com/user/FillOk535/",
        "https://old.reddit.com/user/missjane87/",
        "https://old.reddit.com/user/lillianwet/",
        "https://old.reddit.com/user/Expert-Fig7868/",
        "https://old.reddit.com/user/Yinbebecita/",
        "https://old.reddit.com/user/Bbcnews6969/",
        "https://old.reddit.com/user/ColbyFlagi/",
        "https://old.reddit.com/user/rosie_alasia/",
        "https://old.reddit.com/user/KrazyRussianFun33/",
        "https://old.reddit.com/user/CeelCee/",
        "https://old.reddit.com/user/Teamplayax/",
        "https://old.reddit.com/user/Salt_Zebra_423/",
        "https://old.reddit.com/user/LRX19/",
        "https://old.reddit.com/user/unic0rnbab3/",
        "https://old.reddit.com/user/Kynng_Thot/",
        "https://old.reddit.com/user/submissive-freeuse/",
        "https://old.reddit.com/user/MagnoBorrowo/",
        "https://old.reddit.com/user/PageCompetitive9746/",
        "https://old.reddit.com/user/2manic4u/",
        "https://old.reddit.com/user/SexmonkeyScarlet/",
        "https://old.reddit.com/user/Mindless-Debate-2422/",
        "https://old.reddit.com/user/Sofieshh/",
        "https://old.reddit.com/user/slut19072/",
        "https://old.reddit.com/user/MoistRequirement3021/",
        "https://old.reddit.com/user/Aussiemilf2046/",
        "https://old.reddit.com/user/NoonWraithDance/",
        "https://old.reddit.com/user/thrown2thewolves53/",
        "https://old.reddit.com/user/chromegrill/",
        "https://old.reddit.com/user/Effective_Poetry_789/",
        "https://old.reddit.com/user/AlexaAdmireo",
        "https://old.reddit.com/user/Jilliebeans112",
        "https://old.reddit.com/user/Naughtycouple6969",
        "https://old.reddit.com/user/FarrahPFister",
        "https://old.reddit.com/user/Own_me10001",
        "https://old.reddit.com/user/WatercressJust770",
        "https://old.reddit.com/user/Euphoric-Beginning60",
        "https://old.reddit.com/user/dadbod980",
        "https://old.reddit.com/user/2missmae",
        "https://old.reddit.com/user/caprioworks",
        "https://old.reddit.com/user/bigw0r",
        "https://old.reddit.com/user/Economy-Programmer-7",
        "https://old.reddit.com/user/Majestic_Bad112",
        "https://old.reddit.com/user/openwetnwide",
        "https://old.reddit.com/user/gndownwife",
        "https://old.reddit.com/user/Pikabois",
        "https://old.reddit.com/user/FullWork0",
        "https://old.reddit.com/user/southrnchevyboy",
        "https://old.reddit.com/user/sk_sobaka555",
        "https://old.reddit.com/user/hot_gf1997",
        "https://old.reddit.com/user/Tattooedchef_4u",
        "https://old.reddit.com/user/chargabe_11",
        "https://old.reddit.com/user/BaylahB",
        "https://old.reddit.com/user/freakslutsage",
        "https://old.reddit.com/user/Diesel_gang24v",
        "https://old.reddit.com/user/dos_biscuits",
        "https://old.reddit.com/user/BaylahB",
        "https://old.reddit.com/user/Odd-Ad6334",
        "https://old.reddit.com/user/Skeltorsmokee",
        "https://old.reddit.com/user/ceded15",
        "https://old.reddit.com/user/sophiab63",
        "https://old.reddit.com/user/Browneyedbrat3",
        "https://old.reddit.com/user/No_Mention_4550",
        "https://old.reddit.com/user/Adventurous_Top_4492",
        "https://old.reddit.com/user/daydreamingprisoner-",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",

        // listDeletes
    ];


    let goodlist = [
        "https://old.reddit.com/user/L0v2Str3tch/",
        "https://old.reddit.com/user/LooseyGooseyEva/",
        "https://old.reddit.com/user/DLF21/",
        "https://old.reddit.com/user/VixenxMoon/",
        "https://old.reddit.com/user/crazywifeslut/",
        "https://old.reddit.com/user/Even-Aioli7876/",
        "https://old.reddit.com/user/HornyLinaFox/",
        "https://old.reddit.com/user/_joseywalesss/",
        "https://old.reddit.com/user/babymoonsun/",
        "https://old.reddit.com/user/Str3tchyness/",
        "https://old.reddit.com/user/justlooking_94/",
        "https://old.reddit.com/user/jocaladium/",
        "https://old.reddit.com/user/Maxeengreen/",
        "https://old.reddit.com/user/ShowOffCandy/",
        "https://old.reddit.com/user/bigyoni95/",
        "https://old.reddit.com/user/sizeprincessnina/",
        "https://old.reddit.com/user/leaksfrommybedroom/",
        "https://old.reddit.com/user/SukiExploring/",
        "https://old.reddit.com/user/YourFavSlut21/",
        "https://old.reddit.com/user/Pusscakess/",
        "https://old.reddit.com/user/IBM--5100/",
        "https://old.reddit.com/user/RocheLimit9492/",
        "https://old.reddit.com/user/PunkdPrincess/",
        "https://old.reddit.com/user/loosepussyland",
        "https://old.reddit.com/user/Monika_Fox/",
        "https://old.reddit.com/user/SassyGirl-Ok",
        "https://old.reddit.com/user/OrangeMouse1250",
        "https://old.reddit.com/user/Ok_Dragonfly_666",
        "https://old.reddit.com/user/openpuss",
        "https://old.reddit.com/user/TheDawlMaker",
        "https://old.reddit.com/user/Important-Mix-3745",
        "https://old.reddit.com/user/serp75",
        "https://old.reddit.com/user/angeldoves",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        // goodlist
    ];

    listDeletes.push(...goodlist);



    document.querySelectorAll(".link").forEach(e=>{e.style="margin-bottom: 15px"});
    document.querySelectorAll(".thumbnail").forEach(e=>{e.style="width: auto; margin-right: 10px;"});
    document.querySelectorAll(".thumbnail img").forEach(e=>{e.style="width: 100% !important; height: auto !important;"});


    function isContainUrl() {
        for (let i = 0; i < listDeletes.length; i++) {
            if ((window.location.href).includes(listDeletes[i]) && (listDeletes[i]) != '') {
                return true;
            }
        }
        return false;
    }


    function urlSiteCrop(url) {
        let output = url.replace("https://www.reddit.com", "");
        return output;
    };


    function delBoxes() {
        if (isContainUrl()) {
            document.querySelector(`body`).remove();
            document.querySelector("html").style="background-color:aqua;";
            return;
        }

        let alllinks = document.querySelectorAll(`.thing`);
        let linksinclude = [];

        for (let i = 0; i < alllinks.length; i++) {
            let data_author = alllinks[i].getAttribute("data-author");
            if(listDeletes.includes("https://old.reddit.com/user/" + data_author + "/") || listDeletes.includes("https://old.reddit.com/user/" + data_author)){
                linksinclude.push(alllinks[i]);
            }
        }
        linksinclude.forEach(e=>e.closest(".thing").remove());
    }
    delBoxes();




})();