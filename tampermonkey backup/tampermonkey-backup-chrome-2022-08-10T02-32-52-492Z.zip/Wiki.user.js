// ==UserScript==
// @name         Wiki
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://ru.wikipedia.org/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=wikipedia.org
// @grant        none
// ==/UserScript==

(function() {
    let listDeletes = [
        "https://ru.wikipedia.org/wiki/%D0%97%D0%B0%D1%83%D1%87%D0%B8%D0%B2%D0%B0%D0%BD%D0%B8%D0%B5_%D0%BD%D0%B0%D0%B8%D0%B7%D1%83%D1%81%D1%82%D1%8C",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
    ];

    function urlSiteCrop(url) {
        let output = url.replace("https://ru.wikipedia.org", "");
        return output;
    };

    function delBoxes() {
        for (let i = 0; i < listDeletes.length; i++) {
            //   document.querySelectorAll(`.pcVideoListItem a[href^="${urlSiteCrop(listDeletes[i])}"`).forEach(e => e.closest('li').remove());

            const links = document.querySelectorAll(`a[href="${urlSiteCrop(listDeletes[i])}"]`);
            links.forEach(link => {
                const el = document.createElement('span')
                el.textContent = link.textContent
                link.parentNode.replaceChild(el, link)
            })
        }
    }
    delBoxes();

})();