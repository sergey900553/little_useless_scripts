// ==UserScript==
// @name         OpenaAll
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://nhentai.net/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=nhentai.net
// @grant        none
// ==/UserScript==

(function() {
    'use strict';




    let addToList = document.createElement(`button`);
    addToList.id = "openAll";
    addToList.innerHTML = "Открыть все";
    addToList.classList ="btn btn-primary tooltip";
    console.log(addToList);


    if(document.querySelector(".container.index-container")){
        if (document.querySelector(".menu.left")) {
            document.querySelector(".menu.left").append(addToList);
        }
    }






    addToList.addEventListener('click', function () {

        openAll();
    }
                              );












    function sleep(milliseconds) {
        let start = new Date().getTime();
        for (let i = 0; i < 1e7; i++) {
            if ((new Date().getTime() - start) > milliseconds){
                break;
            }
        }
    }


  /* function openAll(){
        let links = Array.from(document.querySelectorAll(".index-container a")).reverse();

        for (let i = 0; i < links.length; i++) {

            window.open(links[i], '_blank');

            sleep(300);
        }
    }
*/



    function openAll() {
        let links = Array.from(document.querySelectorAll(".index-container a")).reverse();

        links.forEach((item, i) => {
            setTimeout(() => {
                window.open(item, '_blank');
            }, i * 300);
        });
    }

})();