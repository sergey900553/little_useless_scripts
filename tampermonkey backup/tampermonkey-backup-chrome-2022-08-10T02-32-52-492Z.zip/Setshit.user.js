// ==UserScript==
// @name         Setshit
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://nhentai.net/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=nhentai.net
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    // localStorage.setItem('items-shit', 5);


    let counterer = localStorage.getItem('items-shit') ? JSON.parse(localStorage.getItem('items-shit')) : -1;

    setTimeout(function () {
        if (counterer == 0) {
            //   document.querySelector(".container.index-container").replaceChildren();
        }
    }, 1000);


    setTimeout(function () {
        if (counterer == 0) {
         

            for (let i = 0; i < JSON.parse(localStorage.getItem('items-gallery')).length; i++) {
                let str = JSON.parse(localStorage.getItem('items-gallery'))[i];
                let element = document.querySelector(".container.index-container");
                element.insertAdjacentHTML('beforeend', str);
            }

            let allElements = document.querySelectorAll(".gallery");
            for (let i = 0; i < allElements.length; i++) {
                let imageDataScr = document.querySelectorAll(".gallery a img")[i].getAttribute('data-src');
                let imageScrNew = document.querySelectorAll(".gallery a img")[i].setAttribute("src", imageDataScr);
            }

            localStorage.setItem('items-shit', counterer - 1);
            localStorage.removeItem('items-gallery');
        }
    }, 2000);



    setTimeout(function () {
        if (counterer > 0) {
            let itemsArrayInStorage = localStorage.getItem('items-gallery') ? JSON.parse(localStorage.getItem('items-gallery')) : [];
            let arrayOfPostsDirty = document.querySelectorAll(".gallery");
            let tempArray = [];
            for (let i = 0; i < arrayOfPostsDirty.length; i++) {
                tempArray.push(arrayOfPostsDirty[i].outerHTML);
            }
            let result_array_with_my_order = tempArray.concat(itemsArrayInStorage);
            localStorage.setItem('items-gallery', JSON.stringify(result_array_with_my_order));
            localStorage.setItem('items-shit', counterer - 1);
        }

    }, 2000);

    setTimeout(function () {
        if (counterer > 0) {
            if (document.querySelector(".previous")){
                document.querySelector(".previous").click();
            } else {
                for (let i = 0; i < JSON.parse(localStorage.getItem('items-gallery')).length; i++) {
                    let str = JSON.parse(localStorage.getItem('items-gallery'))[i];
                    let element = document.querySelector(".container.index-container");
                    element.insertAdjacentHTML('beforeend', str);
                }

                let allElements = document.querySelectorAll(".gallery");
                for (let i = 0; i < allElements.length; i++) {
                    let imageDataScr = document.querySelectorAll(".gallery a img")[i].getAttribute('data-src');
                    let imageScrNew = document.querySelectorAll(".gallery a img")[i].setAttribute("src", imageDataScr);
                }
                localStorage.setItem('items-shit', -1);
                localStorage.removeItem('items-gallery');
            }
        }
    }, 3000);














})();