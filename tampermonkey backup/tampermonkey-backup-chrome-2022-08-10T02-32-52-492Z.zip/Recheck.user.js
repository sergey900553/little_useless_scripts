// ==UserScript==
// @name         Recheck
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://rt.pornhub.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=pornhub.com
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    let listDeletes = [
        //fist
        "https://rt.pornhub.com/model/fianceporn",
        "https://rt.pornhub.com/model/doveyangel",
        "https://rt.pornhub.com/model/sofi_fire",
        "https://rt.pornhub.com/model/reese_peach",
        "https://rt.pornhub.com/model/pantiesqueen",
        "https://rt.pornhub.com/model/takeitallgf",
        "https://rt.pornhub.com/model/jrd1216",
        "https://rt.pornhub.com/model/lizashultz", //
        "https://rt.pornhub.com/model/andrey_zloy",
        "https://rt.pornhub.com/model/alisa-lovely",
        "https://rt.pornhub.com/model/size-princess-nina",
        "https://rt.pornhub.com/model/evadicks",
        "https://rt.pornhub.com/model/whiteblack",
        "https://rt.pornhub.com/model/april-bigass", //
        "https://rt.pornhub.com/model/big-yoni-95", //
        "https://rt.pornhub.com/model/candylisa",
        "https://rt.pornhub.com/model/cute-pussy", //
        "https://rt.pornhub.com/model/pipaypipo",
        "https://rt.pornhub.com/model/aussie-ava",
        "https://rt.pornhub.com/model/sausage-and-donut",
        "https://rt.pornhub.com/model/babylolaxo",
        "https://rt.pornhub.com/model/beastandbeauty",
        "https://rt.pornhub.com/model/messymommy",
        "https://rt.pornhub.com/model/pinkpeppermint",
        "https://rt.pornhub.com/model/solofunxxx",
        "https://rt.pornhub.com/model/happym_eal",
        "https://rt.pornhub.com/model/annutella",
        "https://rt.pornhub.com/model/blondeisland", //
        "https://rt.pornhub.com/model/anonymkitty_of",
        "https://rt.pornhub.com/model/fuckingluvfucking", //
        "https://rt.pornhub.com/model/ambeexx", //
        "https://rt.pornhub.com/model/fallen-angel", //
        "https://rt.pornhub.com/model/solomarie", //
        "https://rt.pornhub.com/model/lina-moore", //
        "https://rt.pornhub.com/model/blonde-ale", //
        "https://rt.pornhub.com/pornstar/masha-yang", //

        // lesbi
        "https://rt.pornhub.com/model/eveandmaddie",
        "https://rt.pornhub.com/model/chellwray",
        "https://rt.pornhub.com/model/rose-and-zoey",
        "https://rt.pornhub.com/model/misshoneyhole",


        //natural
        "https://rt.pornhub.com/model/psyadel",
        "https://rt.pornhub.com/model/foxyelf",
        "https://rt.pornhub.com/model/deborah_pie",
        "https://rt.pornhub.com/model/banana-nomads",
        "https://rt.pornhub.com/model/arktica",
        "https://rt.pornhub.com/model/emma-chase",
        "https://rt.pornhub.com/model/somegirth",
        "https://rt.pornhub.com/model/lil-liza",
        "https://rt.pornhub.com/model/masha69anal",
        "https://rt.pornhub.com/model/smuzililpussy",
        "https://rt.pornhub.com/model/carters-dairy",
        "https://rt.pornhub.com/model/woodlifesex",
        "https://rt.pornhub.com/model/tate",
        "https://rt.pornhub.com/model/arden-tate",
        "https://rt.pornhub.com/model/jess-the-best-bottoms",
        "https://rt.pornhub.com/model/hungry_fox",
        "https://rt.pornhub.com/model/mollykelt",
        "https://rt.pornhub.com/model/stepsisterpov",
        "https://rt.pornhub.com/model/alevtina-violet",
        "https://rt.pornhub.com/model/lilith-cain",
        "https://rt.pornhub.com/model/tenoritaiga",
        "https://rt.pornhub.com/model/vorstikk",
        "https://rt.pornhub.com/model/veronica-fox",
        "https://rt.pornhub.com/model/jastinrabbit",
        "https://rt.pornhub.com/model/queen-white",
        "https://rt.pornhub.com/model/jessalynxxx",
        "https://rt.pornhub.com/model/nanilea47",
        "https://rt.pornhub.com/model/body-lyric",
        "https://rt.pornhub.com/model/sexwithcami",



        //cute
        "https://rt.pornhub.com/model/ellietunes",
        "https://rt.pornhub.com/model/bunnybangz",
        "https://rt.pornhub.com/model/emerald-ethereal",
        "https://rt.pornhub.com/model/alevtina-violet",
        "https://rt.pornhub.com/model/coconey",
        "https://rt.pornhub.com/model/mirari-hub",
        "https://rt.pornhub.com/model/waifusha",
        "https://rt.pornhub.com/model/dirty-dalish",
        "https://rt.pornhub.com/model/eva-veil",
        "https://rt.pornhub.com/model/loren-black",
        "https://rt.pornhub.com/pornstar/yukki-amey",
        "https://rt.pornhub.com/model/bunny_marthy",
        "https://rt.pornhub.com/model/charlotte1996",
        "https://rt.pornhub.com/model/h_art_less",
        "https://rt.pornhub.com/model/petite-alexis",
        "https://rt.pornhub.com/model/alex_slasher",
        "https://rt.pornhub.com/model/reislin",
        "https://rt.pornhub.com/model/pixiepetite",
        "https://rt.pornhub.com/model/kitsuneandnnate",
        "https://rt.pornhub.com/model/leyla-angell",
        "https://rt.pornhub.com/model/gingercuttie12",
        "https://rt.pornhub.com/model/fionaandandy",
        "https://rt.pornhub.com/pornstar/jamie-young",



        //blowjob
        "https://rt.pornhub.com/model/ivy-skye",
        "https://rt.pornhub.com/model/amateurez",
        "https://rt.pornhub.com/model/yourpersonalwaifu",
        "https://rt.pornhub.com/model/my-little-swallow",
        "https://rt.pornhub.com/model/meliprincess",
        "https://rt.pornhub.com/model/mihanika69",
        "https://rt.pornhub.com/model/mimi-boom",
        "https://rt.pornhub.com/model/marcelin-abadir",
        "https://rt.pornhub.com/model/leon-green",
        "https://rt.pornhub.com/model/rmhardco",
        "https://rt.pornhub.com/model/royalhippies",
        //bdsm
        "https://rt.pornhub.com/model/ivy-milk",
        "https://rt.pornhub.com/model/adoredhippie",
        "https://rt.pornhub.com/model/thickythatiana",
        "https://rt.pornhub.com/model/amy-grand",
        "https://rt.pornhub.com/model/little-wolfy",
        "https://rt.pornhub.com/model/smileboy-ii",
        "https://rt.pornhub.com/model/clumsylittlesuby",
        "https://rt.pornhub.com/model/strapon_school",
        "https://rt.pornhub.com/model/naughty-angel-mia",
        "https://rt.pornhub.com/model/eighttwenty/",

        // cuuck
        "https://rt.pornhub.com/model/shishkaboga",
        "https://rt.pornhub.com/model/sayler-vixen", //
        "https://rt.pornhub.com/model/possiblyneighbours", //
        "https://rt.pornhub.com/model/theneighbours", //




    ];


    function isExistAqua(){
        waitForElm('#recheck').then((span) => {
            span.style.color="#00ff6f";
        });
    }

    function ifExistChangeColorOfVideo() {
        let userInfo = document.querySelector(".userInfo .usernameBadgesWrapper a");
        if (userInfo == null) return;
        if (!listDeletes.includes(userInfo.href)) return;

        let H1 = document.querySelector(".inlineFree");
        H1.style.color = "red";
        isExistAqua();
    }

    function ifExistChangeColorOfProfile() {
        let profile = document.querySelector("#profileHome a");
        if (profile == null) return;
        if (!listDeletes.includes(profile.href)) return;

        let H1 = document.querySelector(".nameSubscribe h1");
        H1.style.color = "red";
         isExistAqua();
    }

    function urlSiteCrop(url) {
        let output = url.replace("https://rt.pornhub.com", "");
        return output;
    };


    function delBoxes() {
        let alllinks = document.querySelectorAll(`.pcVideoListItem .usernameWrap a`);
        let linksinclude = [];

        for (let i = 0; i < alllinks.length; i++) {
            if(listDeletes.includes(alllinks[i].href)){
                linksinclude.push(alllinks[i]);
            }
        }
        linksinclude.forEach(e=>e.closest("li").remove());
    }

    function waitForElm(selector) {
        return new Promise(resolve => {
            if (document.querySelector(selector)) {
                return resolve(document.querySelector(selector));
            }

            const observer = new MutationObserver(mutations => {
                if (document.querySelector(selector)) {
                    resolve(document.querySelector(selector));
                    observer.disconnect();
                }
            });

            observer.observe(document.body, {
                childList: true,
                subtree: true
            });
        });
    }

    function ifisChanged(selector, runfunction) {
        if (document.querySelector(selector) == null) {
            return console.log("Элемента не существует");
        }

        const observer = new MutationObserver(function (mutation) {
            mutation.forEach(function (mutation) {
                if (mutation.addedNodes.length) {
                    runfunction();
                }
            })
        });

        observer.observe(document.querySelector(selector), {
            childList: true,
            attributes: true,
            subtree: true,
            characterData: true,
        })
    };




    ////////////////////////////////////////

    ifExistChangeColorOfVideo();
    ifExistChangeColorOfProfile();

    if (document.querySelector('.videoUList') != null && (window.location.href).includes("videos") == null) {
        delBoxes();
    }

    if (document.querySelector('.video-wrapper.js-relatedRecommended.js-relatedVideos.relatedVideos') != null) {
        delBoxes();
    }


    waitForElm('#updateList').then((selectButton) => {
        selectButton.addEventListener('click', function () {
            delBoxes();
        })
    });

    ifisChanged('.videoUList', delBoxes);





})();