// ==UserScript==
// @name         IfScoreDeleteFilms
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.kinopoisk.ru/film/*/like/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=kinopoisk.ru
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

function delBoxes() {
    let score = ["1","2","3","4","5","6","7","8","9","10"];

    let scoresFilms = document.querySelectorAll(`.myVote p`);
    scoresFilms.forEach(e=>{
        if (score.includes(e.innerHTML)){
            e.closest("._NO_HIGHLIGHT_").remove();
        }
    });
}
delBoxes();
})();