// ==UserScript==
// @name         OpenPlaylists
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://rt.pornhub.com/users/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=pornhub.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    function OpenAllPlaylistsButton() {
        if (window.location.href.includes("playlists") != true) {
            return false;
        }


        let openAllPlaylists = document.createElement(`button`);
        openAllPlaylists.id = "openAllPlaylists";
        openAllPlaylists.innerHTML = `Открыть все (${document.querySelectorAll("#moreData .title.display-block a").length}) плейлисты`;
        openAllPlaylists.style = "margin-left: 10px; cursor: pointer;";

        let selector = document.querySelector(".section_header.separated.first .float-left h1");

        if (selector) {
            selector.append(openAllPlaylists)
        }

        if (selector) {
            selector.append(openAllPlaylists);
        }



        const observer1 = new MutationObserver(function (mutation) {
            mutation.forEach(function (mutation) {
                if (mutation.addedNodes.length) {
                    openAllPlaylists.innerHTML = `Открыть все (${document.querySelectorAll("#moreData .title.display-block a").length}) плейлисты`;
                }
            })
        });


        if (document.querySelector('#moreData') != null) {
            const playlistWrapper1 = document.querySelector('#moreData');
            observer1.observe(playlistWrapper1, {
                childList: true,
                subtree: true,
            })
        }
        /////////////////


        openAllPlaylists.addEventListener('click', function () {
            let links = document.querySelectorAll("#moreData .title.display-block a");

            let items_playlists = localStorage.getItem('items-playlist') ? JSON.parse(localStorage.getItem('items-playlist')) : [];
            let uniqueLinks = [];
            links.forEach(e=>{
                if(!items_playlists.includes(e.href)){
                    uniqueLinks.push(e.href);
                }
            });

            if (uniqueLinks != 0){
                uniqueLinks.forEach((item, i) => {
                    setTimeout(() => {
                        window.open(item, '_blank');
                    }, i * 100);
                });
            }
            if (uniqueLinks == 0){
                alert("Уже все добавлено");
            }
        });


    }


    OpenAllPlaylistsButton();

})();