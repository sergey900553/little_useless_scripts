// ==UserScript==
// @name         Youtube
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.youtube.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=youtube.com
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    let listDeletes = [
        "",
        "",
        "",
    ];

    function urlSiteCrop(url) {
        let output = url.replace("https://www.youtube.com", "");
        return output;
    };


    function delBoxes() {

        for (let i = 0; i < listDeletes.length; i++) {
            document.querySelectorAll(`.style-scope.ytd-item-section-renderer a[href^="${urlSiteCrop(listDeletes[i])}"`).forEach(e => e.closest('.style-scope.ytd-item-section-renderer').remove());
        }
    }

    delBoxes();




    const observer0 = new MutationObserver(function (mutation) {
        mutation.forEach(function (mutation) {
            if (mutation.addedNodes.length) {
                delBoxes();
            }
        })
    });

    if (document.querySelector('#related') != null) {
        const playlistWrapper = document.querySelector('#related');
        observer0.observe(playlistWrapper, {
            childList: true,
            subtree: true,
        })
    }


})();