// ==UserScript==
// @name         AddToList
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://nhentai.net/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=nhentai.net
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    let addToList = document.createElement(`button`);
    addToList.id = "addToList";
    addToList.innerHTML = "Добавить в список";
    addToList.classList ="btn btn-primary tooltip";

    if (document.querySelector("#info .buttons")) {
        document.querySelector("#info .buttons").append(addToList);
    }




    document.onkeydown = function(e){
        if(event.ctrlKey && e.keyCode=='66') {
            document.getElementById("addToList").click();
            document.querySelector("#info .pretty").style.color="cyan";
        }
    }



    addToList.addEventListener('click', function () {
        let itemsArray = localStorage.getItem('items-hentai') ? JSON.parse(localStorage.getItem('items-hentai')) : []
        localStorage.setItem('items-hentai', JSON.stringify(itemsArray))
        itemsArray.push(window.location.href);
        localStorage.setItem('items-hentai', JSON.stringify(itemsArray))
    }
                              );


    /////////////////////////////

    function urlSiteCrop(url) {
        let output = url.replace("https://nhentai.net", "");
        return output;
    };



    function UpdateList() {
        let items_hentai = JSON.parse(localStorage.getItem('items-hentai'));
        if (items_hentai != null) {
            let alllinks = document.querySelectorAll(`.gallery a`);
            let linksinclude = [];

            for (let i = 0; i < alllinks.length; i++) {
                if (items_hentai.includes(alllinks[i].href)){
                    linksinclude.push(alllinks[i]);
                }
            }
            linksinclude.forEach(e => e.closest(".gallery").remove());
        }
    }

    UpdateList();

    const observer = new MutationObserver(function (mutation) {
        mutation.forEach(function (mutation) {
            if (mutation.addedNodes.length) {
                UpdateList();
            }
        })
    });


    if (document.querySelector('.index-container') != null) {
        const playlistWrapper1 = document.querySelector('.index-container');
        observer.observe(playlistWrapper1, {
            childList: true,
            attributes: true,
            subtree: true,
            characterData: true,
        })
    }



})();