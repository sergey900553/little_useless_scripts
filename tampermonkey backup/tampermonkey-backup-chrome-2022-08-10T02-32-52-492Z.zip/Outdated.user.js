// ==UserScript==
// @name         Outdated
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://rt.pornhub.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=pornhub.com
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    let listDeletes = [

        //fist more then 1 year or done
        "https://rt.pornhub.com/model/dripnymph",
        "https://rt.pornhub.com/model/barbieroom",
        "https://rt.pornhub.com/model/she2do100",
        "https://rt.pornhub.com/model/digital_geisha",
        "https://rt.pornhub.com/model/meliknox",
        "https://rt.pornhub.com/model/kiss1couple",
        "https://rt.pornhub.com/model/daisy-deep",
        "https://rt.pornhub.com/model/mayya-moore",
        "https://rt.pornhub.com/model/sofimilf",
        "https://rt.pornhub.com/model/juicylovers",
        "https://rt.pornhub.com/model/nymphonessy",
        "https://rt.pornhub.com/model/kourtney-malkovich",
        "https://rt.pornhub.com/model/natalieflowers",
        "https://rt.pornhub.com/model/husband-fist-wife",
        "https://rt.pornhub.com/model/desireflareup",
        "https://rt.pornhub.com/model/angel-luvin",
        "https://rt.pornhub.com/model/orgasmesanonymes",
        "https://rt.pornhub.com/model/thepleasureescape",
        "https://rt.pornhub.com/model/beautybunnybutt",
        "https://rt.pornhub.com/model/piskiply",
        "https://rt.pornhub.com/model/yourstepsis",
        "https://rt.pornhub.com/model/lilsnowbunnyy",
        "https://rt.pornhub.com/model/tawney-mae",
        "https://rt.pornhub.com/model/avrilxlust",
        "https://rt.pornhub.com/model/madison-rainn",
        "https://rt.pornhub.com/model/mynewprofession",
        "https://rt.pornhub.com/model/zooeyheart",
        "https://rt.pornhub.com/model/mimi_skinny",
        "https://rt.pornhub.com/model/sweetykatty",
        "https://rt.pornhub.com/model/hannahwets",
        "https://rt.pornhub.com/model/jane-bellasario",
        "https://rt.pornhub.com/model/midgeandkali69",
        "https://rt.pornhub.com/model/matokddl45",
        "https://rt.pornhub.com/model/tiredyke",
        "https://rt.pornhub.com/model/kate-wank",
        "https://rt.pornhub.com/model/moon-christine",
        "https://rt.pornhub.com/model/anastasiaxxll",
        "https://rt.pornhub.com/model/thesecretlove",
        "https://rt.pornhub.com/model/analyasexy",
        "https://rt.pornhub.com/model/tessaya-mong",
        "https://rt.pornhub.com/model/dteasedcoxxx",
        "https://rt.pornhub.com/model/pervertblondie",
        "https://rt.pornhub.com/model/kariluk",
        "https://rt.pornhub.com/model/emily-laurenn",
        "https://rt.pornhub.com/model/nastea_xo",
        "https://rt.pornhub.com/model/your-friend-emma",
        "https://rt.pornhub.com/model/emma-exotic",
        "https://rt.pornhub.com/model/sweet_noodle",
        "https://rt.pornhub.com/model/amazingamelie",
        "https://rt.pornhub.com/model/milly1776",
        "https://rt.pornhub.com/model/cherry-kittyn",
        "https://rt.pornhub.com/model/psykat69",
        "https://rt.pornhub.com/model/melissalafolly",
        "https://rt.pornhub.com/model/frenchblondie",
        "https://rt.pornhub.com/model/cat4you",
        "https://rt.pornhub.com/model/nymeria-jade",
        "https://rt.pornhub.com/model/elsagrey18",
        "https://rt.pornhub.com/model/asmrouge",
        "https://rt.pornhub.com/model/younglooseslut",
        "https://rt.pornhub.com/model/vixenmoon",
        "https://rt.pornhub.com/model/thedawlmaker",
        "https://rt.pornhub.com/model/anon0988",
        "https://rt.pornhub.com/model/sweetandsensitive",
        "https://rt.pornhub.com/model/lexie-grace",
        "https://rt.pornhub.com/model/lucy-chambers",
        "https://rt.pornhub.com/model/aurora-rose",
        "https://rt.pornhub.com/model/beauty_hole",
        "https://rt.pornhub.com/model/littlepoisonprince",
        "https://rt.pornhub.com/model/jana-bella",
        "https://rt.pornhub.com/model/roxyjoy",
        "https://rt.pornhub.com/model/aqueries",
        "https://rt.pornhub.com/model/litsisca",
        "https://rt.pornhub.com/model/couplecali",
        "https://rt.pornhub.com/model/hcombs18",
        "https://rt.pornhub.com/model/hotsexykiska",
        "https://rt.pornhub.com/model/breebaby420",
        "https://rt.pornhub.com/model/ariel-blaze",
        "https://rt.pornhub.com/model/littlelillyfckslut",
        "https://rt.pornhub.com/model/kittynkfantasy",
        "https://rt.pornhub.com/model/facelessfuckersss",
        "https://rt.pornhub.com/model/bananacreammuffin",
        "https://rt.pornhub.com/model/bigdickfornikki",
        "https://rt.pornhub.com/model/alesia-ionesco",
        "https://rt.pornhub.com/model/teendidi",
        "https://rt.pornhub.com/model/baddragonslayer",
        "https://rt.pornhub.com/model/simplytawney",
        "https://rt.pornhub.com/model/amateurhour19",
        "https://rt.pornhub.com/model/barbenia",
        "https://rt.pornhub.com/model/ss1978z",
        "https://rt.pornhub.com/model/solo-banger",
        "https://rt.pornhub.com/model/stormie69flower",
        "https://rt.pornhub.com/model/monsterberry",
        "https://rt.pornhub.com/model/mia-marie",
        "https://rt.pornhub.com/model/alicevernersuicide",
        "https://rt.pornhub.com/model/sweet_2002",
        "https://rt.pornhub.com/model/little_nika18",
        "https://rt.pornhub.com/model/larajuicy",
        "https://rt.pornhub.com/model/liona-white",






        // natural
        "https://rt.pornhub.com/pornstar/angel-emily",
        "https://rt.pornhub.com/model/comely_girl",
        "https://rt.pornhub.com/model/dolores_hub",
        "https://rt.pornhub.com/model/bo-flash",
        "https://rt.pornhub.com/model/imdobygreem",
        "https://rt.pornhub.com/model/amanita_tomato",
        "https://rt.pornhub.com/model/crookedpenis7",
        "https://rt.pornhub.com/model/taylorandlisa",
        "https://rt.pornhub.com/model/officialbf",
        "https://rt.pornhub.com/model/lladventures",
        "https://rt.pornhub.com/model/hannascontent",



        // natural solo
        "https://rt.pornhub.com/model/the-soda",
        "https://rt.pornhub.com/model/mall_li_ka",

        // hairy
        "https://rt.pornhub.com/model/youngnhairy",
        "https://rt.pornhub.com/model/ticticboom",



        //blowjob
        "https://rt.pornhub.com/model/dolly-rud",
        "https://rt.pornhub.com/model/carnikitten",
        "https://rt.pornhub.com/model/mvproduction",
        "https://rt.pornhub.com/model/webtolove",
        "https://rt.pornhub.com/model/leon-green",
        "https://rt.pornhub.com/model/jess-and-jamez",


        //cute done
        "https://rt.pornhub.com/model/sonyaxmark",
        "https://rt.pornhub.com/pornstar/jamie-young",
        "https://rt.pornhub.com/model/daddie-maddie",
        "https://rt.pornhub.com/model/kat_fox",
        "https://rt.pornhub.com/model/eevee-frost",
        "https://rt.pornhub.com/model/alicebong",
        "https://rt.pornhub.com/model/itsvalkyrie",
        "https://rt.pornhub.com/model/jessica-starling",
        "https://rt.pornhub.com/model/nanihot1",
        "https://rt.pornhub.com/model/j-clims",
        "https://rt.pornhub.com/model/sexy_borsch",
        "https://rt.pornhub.com/pornstar/cherry-crush",
        "https://rt.pornhub.com/model/sheclover",
        "https://rt.pornhub.com/pornstar/indigo-white",
        "https://rt.pornhub.com/model/mollyredwolf",
        "https://rt.pornhub.com/model/mere-trix",
        "https://rt.pornhub.com/model/nickiblack",
        "https://rt.pornhub.com/model/savannah-montana",
        "https://rt.pornhub.com/model/elunaxc",
        "https://rt.pornhub.com/model/sweetie-fox",
        "https://rt.pornhub.com/model/honey-booboo",
        "https://rt.pornhub.com/model/samantha-flair-official",
        "https://rt.pornhub.com/pornstar/maru-karv",
        "https://rt.pornhub.com/model/baby1476",
        "https://rt.pornhub.com/model/cute-giraffe",
        "https://rt.pornhub.com/model/lucy-scott",
        "https://rt.pornhub.com/model/tessa-winters",
        "https://rt.pornhub.com/model/rainy_storm",
        "https://rt.pornhub.com/model/purple-bitch",
        "https://rt.pornhub.com/model/gia-baker",
        "https://rt.pornhub.com/model/stormy",
        "https://rt.pornhub.com/model/sweet-lita",
        "https://rt.pornhub.com/model/solazola",
        "https://rt.pornhub.com/pornstar/mary-moody",
        "https://rt.pornhub.com/model/californiababe",
        "https://rt.pornhub.com/model/angel",
        "https://rt.pornhub.com/model/moonfleur",
        "https://rt.pornhub.com/model/lilcanadiangirl",
        "https://rt.pornhub.com/model/little-lee",
        "https://rt.pornhub.com/model/babygirlxx17",
        "https://rt.pornhub.com/model/nikky_dandelion",
        "https://rt.pornhub.com/model/yummyliu",
        "https://rt.pornhub.com/model/anibutler",
        "https://rt.pornhub.com/model/baristababe8",
        "https://rt.pornhub.com/model/alicemoonstone",
        "https://rt.pornhub.com/model/freya-stein",
        "https://rt.pornhub.com/model/katekuray",
        "https://rt.pornhub.com/model/semulv",
        "https://rt.pornhub.com/model/venus-kitty",
        "https://rt.pornhub.com/model/hot-bella",
        "https://rt.pornhub.com/model/lillypillyhell",
        "https://rt.pornhub.com/model/mattiedoll",
        "https://rt.pornhub.com/model/thefoxalina",
        "https://rt.pornhub.com/model/alicemfc",
        "https://rt.pornhub.com/model/lunita44",
        "https://rt.pornhub.com/model/evaava",
        "https://rt.pornhub.com/model/mollymoonsugar",
        "https://rt.pornhub.com/model/shinaryen",
        "https://rt.pornhub.com/model/my_little_betsy",
        "https://rt.pornhub.com/model/sofia-simens",
        "https://rt.pornhub.com/model/belleniko",
        "https://rt.pornhub.com/model/paletattoos",

        //milf
        "https://rt.pornhub.com/model/daily8",


        //bdsm
        "https://rt.pornhub.com/model/rosieandalena",
        "https://rt.pornhub.com/model/marci-mayhem-x-ty-baker",

        //pregnant
        "https://rt.pornhub.com/model/greydesire69",



    ];

    function isExistAqua(){
        waitForElm('#outdate').then((span) => {
            span.style.color="#00ff6f";
        });
    }

    function ifExistChangeColorOfVideo() {
        let userInfo = document.querySelector(".userInfo .usernameBadgesWrapper a");
        if (userInfo == null) return;
        if (!listDeletes.includes(userInfo.href)) return;

        let H1 = document.querySelector(".inlineFree");
        H1.style.color = "red";
        isExistAqua();
    }

    function ifExistChangeColorOfProfile() {
        let profile = document.querySelector("#profileHome a");
        if (profile == null) return;
        if (!listDeletes.includes(profile.href)) return;

        let H1 = document.querySelector(".nameSubscribe h1");
        H1.style.color = "red";
         isExistAqua();
    }

    function urlSiteCrop(url) {
        let output = url.replace("https://rt.pornhub.com", "");
        return output;
    };


    function delBoxes() {
        let alllinks = document.querySelectorAll(`.pcVideoListItem .usernameWrap a`);
        let linksinclude = [];

        for (let i = 0; i < alllinks.length; i++) {
            if(listDeletes.includes(alllinks[i].href)){
                linksinclude.push(alllinks[i]);
            }
        }
        linksinclude.forEach(e=>e.closest("li").remove());
    }

    function waitForElm(selector) {
        return new Promise(resolve => {
            if (document.querySelector(selector)) {
                return resolve(document.querySelector(selector));
            }

            const observer = new MutationObserver(mutations => {
                if (document.querySelector(selector)) {
                    resolve(document.querySelector(selector));
                    observer.disconnect();
                }
            });

            observer.observe(document.body, {
                childList: true,
                subtree: true
            });
        });
    }

    function ifisChanged(selector, runfunction) {
        if (document.querySelector(selector) == null) {
            return console.log("Элемента не существует");
        }

        const observer = new MutationObserver(function (mutation) {
            mutation.forEach(function (mutation) {
                if (mutation.addedNodes.length) {
                    runfunction();
                }
            })
        });

        observer.observe(document.querySelector(selector), {
            childList: true,
            attributes: true,
            subtree: true,
            characterData: true,
        })
    };




    ////////////////////////////////////////

    ifExistChangeColorOfVideo();
    ifExistChangeColorOfProfile();

    if (document.querySelector('.videoUList') != null && (window.location.href).includes("videos") == null) {
        delBoxes();
    }

    if (document.querySelector('.video-wrapper.js-relatedRecommended.js-relatedVideos.relatedVideos') != null) {
        delBoxes();
    }


    waitForElm('#updateList').then((selectButton) => {
        selectButton.addEventListener('click', function () {
            delBoxes();
        })
    });

    ifisChanged('.videoUList', delBoxes);




})();