// ==UserScript==
// @name         playlist buttons
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://rt.pornhub.com/playlist/*
// @match     https://rt.pornhub.com/users/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=pornhub.com
// @grant        none
// ==/UserScript==

(function () {
    'use strict';
    if (document.querySelector(".playlist-action")){
        document.querySelector(".playlist-action").style = "display: flex; align-items: center;"
    }
    let btnClass = "greyButton light";
    let btnStyle = "margin-left: 5px; cursor: pointer; font-size: 12px; font-weight: 400; border-radius: 2px;";


    let updateListButton = document.createElement(`button`);
    updateListButton.id = "updateList";
    updateListButton.innerHTML = "Обновить список";
    updateListButton.classList = btnClass;
    updateListButton.style = btnStyle;



    if (document.querySelector(".playlist-action")) {
        document.querySelector(".playlist-action").append(updateListButton)
    }




    function UpdateList() {
        if (JSON.parse(localStorage.getItem('items')) != null) {

            let alllinks = document.querySelectorAll(`.pcVideoListItem a`);
            let listDeletes = JSON.parse(localStorage.getItem('items'));
            let linksinclude = [];

            for (let i = 0; i < alllinks.length; i++) {
                if (listDeletes.includes(alllinks[i].href)) {
                    linksinclude.push(alllinks[i]);
                }
            }
            linksinclude.forEach(e => e.closest("li").remove());

        }


        if (JSON.parse(localStorage.getItem('items-later')) != null) {

            let alllinks = document.querySelectorAll(`.pcVideoListItem a`);
            let listDeletes = JSON.parse(localStorage.getItem('items-later'));
            let linksinclude = [];

            for (let i = 0; i < alllinks.length; i++) {
                if (listDeletes.includes(alllinks[i].href)) {
                    linksinclude.push(alllinks[i]);
                }
            }
            linksinclude.forEach(e => e.closest("li").remove());

        }

        if (JSON.parse(localStorage.getItem('items-cute')) != null) {

            let alllinks = document.querySelectorAll(`.pcVideoListItem a`);
            let listDeletes = JSON.parse(localStorage.getItem('items-cute'));
            let linksinclude = [];

            for (let i = 0; i < alllinks.length; i++) {
                if (listDeletes.includes(alllinks[i].href)) {
                    linksinclude.push(alllinks[i]);
                }
            }
            linksinclude.forEach(e => e.closest("li").remove());

        }
    }


    updateListButton.addEventListener('click', function () {
        UpdateList();
    })



    const observer1 = new MutationObserver(function (mutation) {
        mutation.forEach(function (mutation) {
            if (mutation.addedNodes.length) {
                UpdateList();
            }
        })
    });


    if (document.querySelector('.videoUList') != null) {
        const playlistWrapper1 = document.querySelector('.videoUList');
        observer1.observe(playlistWrapper1, {
            childList: true,
            attributes: true,
            subtree: true,
            characterData: true,
        })
    }




    /////////////////////////////////////// del chennals


    let delchennals = document.createElement(`button`);
    delchennals.id = "delchennals";
    delchennals.innerHTML = "Удалить каналы";
    delchennals.classList = btnClass;
    delchennals.style = btnStyle;

    if (document.querySelector(".playlist-action")) {
        document.querySelector(".playlist-action").append(delchennals)
    }


    function DelChennals() {
        let chenals = document.querySelectorAll(`.pcVideoListItem.js-pop.videoblock.videoBox.canEdit .usernameWrap a`);
        for (let i = 0; i < chenals.length; i++) {
            if ((chenals[i].href).includes("channels")) {
                chenals[i].closest("li").remove();
            }
        }
    }



    delchennals.addEventListener('click', function () {
        DelChennals();
    })


    /////////////////////////////////////// del pornstar


    let delPornstar = document.createElement(`button`);
    delPornstar.id = "delpornstar";
    delPornstar.innerHTML = "Удалить порнозвезд";
    delPornstar.classList = btnClass;
    delPornstar.style = btnStyle;

    if (document.querySelector(".playlist-action")) {
        document.querySelector(".playlist-action").append(delPornstar)
    }


    function DelPornstar() {
        let chenals = document.querySelectorAll(`.pcVideoListItem.js-pop.videoblock.videoBox.canEdit .usernameWrap a`);
        for (let i = 0; i < chenals.length; i++) {
            if ((chenals[i].href).includes("pornstar")) {
                chenals[i].closest("li").remove();
            }
        }
    }



    delPornstar.addEventListener('click', function () {
        DelPornstar();
    })



    let scrolling = document.createElement(`button`);
    scrolling.id = "scrolling";
    scrolling.innerHTML = "Скроллинг";
    scrolling.classList = btnClass;
    scrolling.style = btnStyle;

    if (document.querySelector(".playlist-action")) {
        document.querySelector(".playlist-action").append(scrolling)
    }


    scrolling.addEventListener('click', function () {

        let id2 = setInterval(function () {

            window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' })

        }, 1000);

        let id1 = setInterval(function () {

            window.scrollTo({ top: document.body.scrollHeight-2000, behavior: 'smooth' });

        }, 2000);




        setTimeout(function () {
            clearInterval(id1);
            clearInterval(id2);
        }, 30000);
    });


    /////

    let openAllLinks = document.createElement(`button`);
    openAllLinks.id = "openAllLinks";
    openAllLinks.innerHTML = "Открыть все профили";
    openAllLinks.classList = btnClass;
    openAllLinks.style = btnStyle;


    if (document.querySelector(".playlist-action")) {
        document.querySelector(".playlist-action").append(openAllLinks)
    }




    openAllLinks.addEventListener('click', function () {

        let allLinks = document.querySelectorAll(`.pcVideoListItem.js-pop.videoblock.videoBox.canEdit .wrap .usernameWrap  a`);

        let uniqueLinks = [];
        allLinks.forEach((element) => {
            if (!uniqueLinks.includes(element.href)) {
                uniqueLinks.push(element.href);
            }
        });

        uniqueLinks.forEach(function (item, i) {
            setTimeout(function () {
                window.open(item, '_blank');
            }, i * 100);
        });
    })


    ////////////////////////////

    let addPlaylist = document.createElement(`button`);
    addPlaylist.id = "addPlaylist";
    addPlaylist.innerHTML = "Добавить плейлист в список";
    addPlaylist.classList = btnClass;
    addPlaylist.style = btnStyle;

    if (document.querySelector(".playlist-action")) {
        document.querySelector(".playlist-action").append(addPlaylist)
    }




    addPlaylist.addEventListener('click', function () {

        let itemsArray = localStorage.getItem('items-playlist') ? JSON.parse(localStorage.getItem('items-playlist')) : []
        if (!itemsArray.includes(window.location.href)) {
            itemsArray.push(window.location.href);
        }
        localStorage.setItem('items-playlist', JSON.stringify(itemsArray))

        ChangeColor();
        ifExistChangeColor();
    })






    function ChangeColor() {
        let alllinks = document.querySelectorAll(`.videos.row-3-thumbs.user-playlist.feedSize .full-width .title.display-block a`);
        let listDeletes = JSON.parse(localStorage.getItem('items-playlist'));
        let linksinclude = [];

        for (let i = 0; i < alllinks.length; i++) {
            if (listDeletes.includes(alllinks[i].href)) {
                linksinclude.push(alllinks[i]);
            }
        }
        linksinclude.forEach((e) => { e.style = "color: red;" });
    }

    ChangeColor();



    function ifExistChangeColor() {
        let listDeletes = JSON.parse(localStorage.getItem('items-playlist'));
        let H1 = document.querySelector(".playlistTitle.watchPlaylistButton.js-watchPlaylistHeader.js-watchPlaylist");

        if (H1 != null) {
            if (listDeletes.includes(window.location.href)) {
                H1.style = "color: red;";
            }
        }
    }
    ifExistChangeColor();




    const observer = new MutationObserver(function (mutation) {
        mutation.forEach(function (mutation) {
            if (mutation.addedNodes.length) {
                ChangeColor();
            }
        })
    });

    if (document.querySelector('.profileVids') != null) {
        const playlistWrapper = document.querySelector('.profileVids');
        observer.observe(playlistWrapper, {
            childList: true,
            attributes: true,
            subtree: true,
            characterData: true,
        })
    }



    document.onkeydown = function (e) {
        if (event.ctrlKey && e.keyCode == '66' && window.location.href.includes("playlist") && document.querySelector("#addPlaylist")) {
            document.getElementById("addPlaylist").click();
        }
    }



    document.addEventListener('keydown', function (e) {
        if (/*event.ctrlKey && */event.shiftKey && e.keyCode == '66' && window.location.href.includes("playlist") && document.querySelector("#addPlaylist")) {
            document.getElementById("updateList").click();
            document.getElementById("delchennals").click();
            document.getElementById("delpornstar").click();
        }
    });

})();