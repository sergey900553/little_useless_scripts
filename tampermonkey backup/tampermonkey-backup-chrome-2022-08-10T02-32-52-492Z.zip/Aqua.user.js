// ==UserScript==
// @name         Aqua
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://rt.pornhub.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=pornhub.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';



    function CreateAquaVideos() {
        let userInfo = document.querySelector(".userInfo");
        if (userInfo == null) return;

        let container = document.createElement(`div`);
        container.id = "containerForCheck";
        userInfo.append(container)


        let styleSpan = "margin-right:4px;"


        function CreateSpan(id,innerHTML,style) {

            let span = document.createElement(`span`);
            span.id = id;
            span.innerHTML = innerHTML;
            span.style = style;
            container.append(span)
        }

        CreateSpan("local_1", "L1", styleSpan);
        CreateSpan("local_2", "L2", styleSpan);
        CreateSpan("local_3", "L3", styleSpan);
        CreateSpan("block", "BLOCK", styleSpan);
        CreateSpan("recheck", "RE", styleSpan);
        CreateSpan("outdate", "OUT", styleSpan);


    }

    function CreateAquaProfile() {
        let profileInfo = document.querySelector(".bottomGradient .name");
        if (profileInfo == null) return;

        let container = document.createElement(`div`);
        container.id = "containerForCheck";
        profileInfo.append(container)


        let styleSpan = "margin-right:4px; font-size: 13pt; font-weight: 600;";

        function CreateSpan(id, innerHTML, style) {
            let span = document.createElement(`span`);
            span.id = id;
            span.innerHTML = innerHTML;
            span.style = style;
            container.append(span)
        }

        CreateSpan("local_1", "L1", styleSpan);
        CreateSpan("local_2", "L2", styleSpan);
        CreateSpan("local_3", "L3", styleSpan);
        CreateSpan("block", "BLOCK", styleSpan);
        CreateSpan("recheck", "RE", styleSpan);
        CreateSpan("outdate", "OUT", styleSpan);

    }

    CreateAquaProfile();


    CreateAquaVideos();


})();