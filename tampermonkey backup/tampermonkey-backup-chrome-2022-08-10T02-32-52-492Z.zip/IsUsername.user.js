// ==UserScript==
// @name         IsUsername
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://rt.pornhub.com/users/*
// @match        https://rt.pornhub.com/playlist/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=pornhub.com
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    let links = [
        "https://rt.pornhub.com/users/gary_fist",
        "https://rt.pornhub.com/users/asvaloff__exp",
        "https://rt.pornhub.com/users/loosepussyfan",
        "https://rt.pornhub.com/users/other11235",
        "https://rt.pornhub.com/users/pa2u2u",
        "https://rt.pornhub.com/users/7inchesormore",
        "https://rt.pornhub.com/users/hugedildos",
        "https://rt.pornhub.com/users/majorpane",
        "https://rt.pornhub.com/users/anuebis",
        "https://rt.pornhub.com/users/odpet",
        "https://rt.pornhub.com/users/canmg",
        "https://rt.pornhub.com/users/demonizer50",
        "https://rt.pornhub.com/users/erik271",
        "https://rt.pornhub.com/users/victore69",
        "https://rt.pornhub.com/users/gapestate",
        "https://rt.pornhub.com/users/locohomero",
        "https://rt.pornhub.com/users/hunter_1337",
        "https://rt.pornhub.com/users/stephanie_19",
        "https://rt.pornhub.com/users/londonstamina",
        "https://rt.pornhub.com/users/donnill0",
        "https://rt.pornhub.com/users/waritokyris",
        "https://rt.pornhub.com/users/tab109",
        "https://rt.pornhub.com/users/bobdill300",
        "https://rt.pornhub.com/users/mick18640",
        "https://rt.pornhub.com/users/dvplike",
        "https://rt.pornhub.com/users/jesusmanson2",
        "https://rt.pornhub.com/users/arhipop",
        "https://rt.pornhub.com/users/komodoros",
        "https://rt.pornhub.com/users/noned22",
        "https://rt.pornhub.com/users/jayteethrowaway",
        "https://rt.pornhub.com/users/w00dyy",
        "https://rt.pornhub.com/users/dongrizzlyx",
        "https://rt.pornhub.com/users/temp720",
        "https://rt.pornhub.com/users/supervideosbr",
        "https://rt.pornhub.com/users/gw123123",
        "https://rt.pornhub.com/users/dannyover",
        "https://rt.pornhub.com/users/johnnyrotten1",
        "https://rt.pornhub.com/users/bobforum",
        "https://rt.pornhub.com/users/mastersur420",
        "https://rt.pornhub.com/users/betabra",
        "https://rt.pornhub.com/users/doc_r1",
        "https://rt.pornhub.com/users/amspha",
        "https://rt.pornhub.com/users/kramnz",
        "https://rt.pornhub.com/users/jaywills31",
        "https://rt.pornhub.com/users/jack7486",
        "https://rt.pornhub.com/users/jb779183",
        "https://rt.pornhub.com/users/dawajfete",
        "https://rt.pornhub.com/users/mylittleponny",
        "https://rt.pornhub.com/users/strident1",
        "https://rt.pornhub.com/users/shadysidef",
        "https://rt.pornhub.com/users/sansad",
        "https://rt.pornhub.com/users/pussy_gaping_girl",
        "https://rt.pornhub.com/users/k-boy",
        "https://rt.pornhub.com/users/pjvga",
        "https://rt.pornhub.com/users/comolokko_m25",
        "https://rt.pornhub.com/users/fistingsleepcreep9",
        "https://rt.pornhub.com/users/babygravytrain",
        "https://rt.pornhub.com/users/pierra",
        "https://rt.pornhub.com/users/mrcandid",
        "https://rt.pornhub.com/users/justaguylooking",
        "https://rt.pornhub.com/users/lildickmanchild",
        "https://rt.pornhub.com/users/babydicknballs",
        "https://rt.pornhub.com/users/massiveme69",
        "https://rt.pornhub.com/users/nikocadizz",
        "https://rt.pornhub.com/users/hotsaucemlbb",
        "https://rt.pornhub.com/users/jrhandsoloist",
        "https://rt.pornhub.com/users/asberch",
        "https://rt.pornhub.com/users/warplane",
        "https://rt.pornhub.com/users/blackpegas",
        "https://rt.pornhub.com/users/kristylagrotta",
        "https://rt.pornhub.com/users/jimmy_xyz",
        "https://rt.pornhub.com/users/pencildick92",
        "https://rt.pornhub.com/users/naughty_tricks",
        "https://rt.pornhub.com/users/sosoxxx",
        "https://rt.pornhub.com/users/thejacksonclay",
        "https://rt.pornhub.com/users/yotehunter",
        "https://rt.pornhub.com/users/yungai_sum",
        "https://rt.pornhub.com/users/defnotap3rv",
        "https://rt.pornhub.com/users/dingbat12463",
        "https://rt.pornhub.com/users/obsidianglass",
        "https://rt.pornhub.com/users/penguinny",
        "https://rt.pornhub.com/users/pink-hunter",
        "https://rt.pornhub.com/users/sfmproductions",
        "https://rt.pornhub.com/users/johannesnimwegen",
        "https://rt.pornhub.com/users/privy21m",
        "https://rt.pornhub.com/users/exporrigo",
        "https://rt.pornhub.com/users/62richard",
        "https://rt.pornhub.com/users/germanonex",
        "https://rt.pornhub.com/users/ilovebigbuts",
        "https://rt.pornhub.com/users/bobbygetton",
        "https://rt.pornhub.com/users/youngloverforever9",
        "https://rt.pornhub.com/users/jonbrando85",
        "https://rt.pornhub.com/users/blackknight592",
        "https://rt.pornhub.com/users/alexanderlook",
        "https://rt.pornhub.com/users/bfull",
        "https://rt.pornhub.com/users/lordsupreme007",
        "https://rt.pornhub.com/users/socialanimal77",
        "https://rt.pornhub.com/users/sol1603",
        "https://rt.pornhub.com/users/noidea02",
        "https://rt.pornhub.com/users/rawpower",
        "https://rt.pornhub.com/users/source1900",
        "https://rt.pornhub.com/users/xilbog",
        "https://rt.pornhub.com/users/jonysrv",
        "",
        "",
        "",

    ];




    function ChangeColorUser() {
        let username = document.querySelector(`.profileUserName a`);

        if (username == null) return;

        if (links.includes(username.href)) {
            username.style = "color:lawngreen;"
        }

    };


    function ChangeColorPlaylistUser() {
        let username = document.querySelector(`#js-aboutPlaylistTabView a`);

        if (username == null) return;

        if (links.includes(username.href)) {
            username.style = "color:lawngreen;"
        }

    };



    ChangeColorUser();
    ChangeColorPlaylistUser();
})();

