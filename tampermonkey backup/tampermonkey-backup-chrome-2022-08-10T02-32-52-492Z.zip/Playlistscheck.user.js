// ==UserScript==
// @name         Playlistscheck
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        #https://rt.pornhub.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=pornhub.com
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    let listDeletes = [
        "",

    ];



    function urlSiteCrop(url) {
        let output = url.replace("https://rt.pornhub.com", "");
        return output;
    };


    function delBoxes() {
        for (let i = 0; i < listDeletes.length; i++) {
            document.querySelectorAll(`.videos.row-3-thumbs.user-playlist.feedSize .full-width .title.display-block a[href^="${urlSiteCrop(listDeletes[i])}"`).forEach(e => e.style = "color: red;");
            console.log(document.querySelectorAll(`.videos.row-3-thumbs.user-playlist.feedSize .full-width .title.display-block a[href^="${urlSiteCrop(listDeletes[i])}"`));
        }
    }
    delBoxes();


    function ifExistChangeColor() {
        if (document.querySelector(".playlistTitle.watchPlaylistButton.js-watchPlaylistHeader.js-watchPlaylist") != null) {
            if (listDeletes.includes(window.location.href)) {
                document.querySelector(".playlistTitle.watchPlaylistButton.js-watchPlaylistHeader.js-watchPlaylist").style = "color: red;";

            }
        }
    }
    ifExistChangeColor();



    const observer = new MutationObserver(function (mutation) {
        mutation.forEach(function (mutation) {
            if (mutation.addedNodes.length) {
                delBoxes();
            }
        })
    });

    if (document.querySelector('.profileVids') != null) {
        const playlistWrapper = document.querySelector('.profileVids');
        observer.observe(playlistWrapper, {
            childList: true,
            attributes: true,
            subtree: true,
            characterData: true,
        })
    }


})();