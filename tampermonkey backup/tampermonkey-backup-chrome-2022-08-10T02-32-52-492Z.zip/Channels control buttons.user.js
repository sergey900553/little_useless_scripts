// ==UserScript==
// @name         Channels control buttons
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://rt.pornhub.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=pornhub.com
// @grant        none
// @exclude    https://rt.pornhusssb.com/model/*
// ==/UserScript==

(function () {
    'use strict';
    function CreateContainerforAllButtons() {
        let container = document.createElement(`div`);
        container.id = "containerOfShit";
        container.style = "display: inline-block; vertical-align: middle;";

        if (document.querySelector(".userInfo")) {
            document.querySelector(".userInfo").after(container)
        }

        if (document.querySelector(".name")) {
            document.querySelector(".name").after(container)
        }
    }

    function CreateFirstColumnButtons() {

        let contaierOfbuttons1 = document.createElement(`div`);
        contaierOfbuttons1.id = "first-container";
        contaierOfbuttons1.style = "display: inline-grid; margin-left: 10px;";
        if(document.querySelector("#containerOfShit")){
            document.querySelector("#containerOfShit").append(contaierOfbuttons1);
        }



        let addToList = document.createElement(`button`);
        addToList.id = "addToList";
        addToList.innerHTML = "Добавить в список";
        addToList.style = "padding: 2px; margin-bottom: 3px; cursor: pointer;";

        if (document.querySelector("#first-container")) {
            document.querySelector("#first-container").append(addToList)
        }

        if (document.querySelector("#first-container")) {
            document.querySelector("#first-container").append(addToList);
        }



        let showList = document.createElement(`button`);
        showList.id = "showList";
        showList.innerHTML = "Показать список";
        showList.style = "padding: 2px; margin-bottom: 3px; cursor: pointer;";

        if (document.querySelector("#first-container")) {
            document.querySelector("#addToList").after(showList)
        }

        if (document.querySelector("#first-container")) {
            document.querySelector("#addToList").after(showList);
        }


        let deleteList = document.createElement(`button`);
        deleteList.id = "deleteList";
        deleteList.innerHTML = "Удалить список";
        deleteList.style = "padding: 2px; margin-bottom: 3px; cursor: pointer;";

        if (document.querySelector("#first-container")) {
            document.querySelector("#showList").after(deleteList)
        }

        if (document.querySelector("#first-container")) {
            document.querySelector("#showList").after(deleteList);
        }
        ///////// MakeFirstColumsDoStuff
        addToList.addEventListener('click', function () {
            if (document.querySelector(`.video-info-row.userRow span a`) != null) {
                let itemsArray = localStorage.getItem('items') ? JSON.parse(localStorage.getItem('items')) : []
                let link = document.querySelector(`.video-info-row.userRow span a`).href;
                if (!itemsArray.includes(link)){
                    itemsArray.push(link);
                }
                localStorage.setItem('items', JSON.stringify(itemsArray))
                ifExistChangeColorOfProfile();
                ifExistChangeColorOfVideo();
            }
            if (document.querySelector(`#profileHome a`) != null) {
                let itemsArray = localStorage.getItem('items') ? JSON.parse(localStorage.getItem('items')) : []
                let link = document.querySelector(`#profileHome a`).href;
                if (!itemsArray.includes(link)){
                    itemsArray.push(link);
                }
                localStorage.setItem('items', JSON.stringify(itemsArray))
                ifExistChangeColorOfProfile();
                ifExistChangeColorOfVideo();
            }

        })

        showList.addEventListener('click', function () {
            if (JSON.parse(localStorage.getItem('items')) == null) {
                alert("Список пустой");
                return;
            }

            function urlSiteCrop(url) {
                let output = url.replace(/^/, `"`).replace(/$/, `",`);
                return output;
            };

            let itemsArray = JSON.parse(localStorage.getItem('items'));

            let output = [];
            for (let i = 0; i < itemsArray.length; i++) {
                output[i] = urlSiteCrop(itemsArray[i]) + ("<br>");
            }

            let newWidnow = window.open("https://rt.pornhub.com/list1","_blank");
            newWidnow.document.write(output.join(""));
            newWidnow.document.close();
        });



        deleteList.addEventListener('click', function () {
            if (confirm("Подтвердить")) {
                localStorage.removeItem('items');
            } else {
                return false;
            }
        })
    }


    function CreateSecondColumnButtons() {
        let contaierOfbuttons2 = document.createElement(`div`);
        contaierOfbuttons2.id = "second-container";
        contaierOfbuttons2.style = "display: inline-grid; margin-left: 10px;";
        if (document.querySelector("#containerOfShit")){
            document.querySelector("#containerOfShit").append(contaierOfbuttons2);
        }




        let addToList1 = document.createElement(`button`);
        addToList1.id = "addToList1";
        addToList1.innerHTML = "Добавить в список Inbox";
        addToList1.style = "padding: 2px; margin-bottom: 3px; cursor: pointer;";


        if (document.querySelector("#second-container")) {
            document.querySelector("#second-container").append(addToList1)
        }

        if (document.querySelector("#second-container")) {
            document.querySelector("#second-container").append(addToList1);
        }



        let showList1 = document.createElement(`button`);
        showList1.id = "showList1";
        showList1.innerHTML = "Показать список Inbox";
        showList1.style = "padding: 2px; margin-bottom: 3px; cursor: pointer;";

        if (document.querySelector("#second-container")) {
            document.querySelector("#addToList1").after(showList1)
        }

        if (document.querySelector("#second-container")) {
            document.querySelector("#addToList1").after(showList1);
        }


        let deleteList1 = document.createElement(`button`);
        deleteList1.id = "deleteList1";
        deleteList1.innerHTML = "Удалить список Inbox";
        deleteList1.style = "padding: 2px; margin-bottom: 3px; cursor: pointer;";

        if (document.querySelector("#second-container")) {
            document.querySelector("#showList1").after(deleteList1)
        }

        if (document.querySelector("#second-container")) {
            document.querySelector("#showList1").after(deleteList1);
        }
        /////// MakeSecondColumsDoStuff
        addToList1.addEventListener('click', function () {
            if (document.querySelector(`.video-info-row.userRow span a`) != null) {
                let itemsArray = localStorage.getItem('items-later') ? JSON.parse(localStorage.getItem('items-later')) : []
                let link = document.querySelector(`.video-info-row.userRow span a`).href;
                if (!itemsArray.includes(link)){
                    itemsArray.push(link);
                }
                localStorage.setItem('items-later', JSON.stringify(itemsArray))
                ifExistChangeColorOfProfile();
                ifExistChangeColorOfVideo();
            }
            if (document.querySelector(`#profileHome a`) != null) {
                let itemsArray = localStorage.getItem('items-later') ? JSON.parse(localStorage.getItem('items-later')) : []
                let link = document.querySelector(`#profileHome a`).href;
                if (!itemsArray.includes(link)){
                    itemsArray.push(link);
                }
                localStorage.setItem('items-later', JSON.stringify(itemsArray))
                ifExistChangeColorOfProfile();
                ifExistChangeColorOfVideo();
            }

        })

        showList1.addEventListener('click', function () {
            if (JSON.parse(localStorage.getItem('items-later')) == null) {
                alert("Список пустой");
                return;
            }

            function urlSiteCrop(url) {
                let output = url.replace(/^/, `"`).replace(/$/, `",`);
                return output;
            };

            let itemsArray = JSON.parse(localStorage.getItem('items-later'));

            let output = [];
            for (let i = 0; i < itemsArray.length; i++) {
                output[i] = urlSiteCrop(itemsArray[i]) + ("<br>");
            }

            let newWidnow = window.open();
            newWidnow.document.write(output.join(""));
            newWidnow.document.close();

        })

        deleteList1.addEventListener('click', function () {
            if (confirm("Подтвердить")) {
                localStorage.removeItem('items-later')
            } else {
                return false;
            }
        })
    }


    function CreateThirdColumnButtons() {
        let contaierOfbuttons3 = document.createElement(`div`);
        contaierOfbuttons3.id = "third-container";
        contaierOfbuttons3.style = "display: inline-grid; margin-left: 10px;";
        if (document.querySelector("#containerOfShit")){
            document.querySelector("#containerOfShit").append(contaierOfbuttons3);

        }



        let addToList2 = document.createElement(`button`);
        addToList2.id = "addToList2";
        addToList2.innerHTML = "Добавить в список 1";
        addToList2.style = "padding: 2px; margin-bottom: 3px; cursor: pointer;";


        if (document.querySelector("#third-container")) {
            document.querySelector("#third-container").append(addToList2)
        }

        if (document.querySelector("#third-container")) {
            document.querySelector("#third-container").append(addToList2);
        }



        let showList2 = document.createElement(`button`);
        showList2.id = "showList2";
        showList2.innerHTML = "Показать список 1";
        showList2.style = "padding: 2px; margin-bottom: 3px; cursor: pointer;";

        if (document.querySelector("#third-container")) {
            document.querySelector("#addToList2").after(showList2)
        }

        if (document.querySelector("#third-container")) {
            document.querySelector("#addToList2").after(showList2);
        }


        let deleteList2 = document.createElement(`button`);
        deleteList2.id = "deleteList2";
        deleteList2.innerHTML = "Удалить список 1";
        deleteList2.style = "padding: 2px; margin-bottom: 3px; cursor: pointer;";

        if (document.querySelector("#third-container")) {
            document.querySelector("#showList2").after(deleteList2)
        }

        if (document.querySelector("#third-container")) {
            document.querySelector("#showList2").after(deleteList2);
        }

        /// MakeThirdColumsDoStuff
        addToList2.addEventListener('click', function () {
            if (document.querySelector(`.video-info-row.userRow span a`) != null) {
                let itemsArray = localStorage.getItem('items-cute') ? JSON.parse(localStorage.getItem('items-cute')) : []
                let link = document.querySelector(`.video-info-row.userRow span a`).href;
                if (!itemsArray.includes(link)){
                    itemsArray.push(link);
                }
                localStorage.setItem('items-cute', JSON.stringify(itemsArray))
                ifExistChangeColorOfProfile();
                ifExistChangeColorOfVideo();
            }


            if (document.querySelector(`#profileHome a`) != null) {
                let itemsArray = localStorage.getItem('items-cute') ? JSON.parse(localStorage.getItem('items-cute')) : []
                let link = document.querySelector(`#profileHome a`).href;
                if (!itemsArray.includes(link)){
                    itemsArray.push(link);
                }
                localStorage.setItem('items-cute', JSON.stringify(itemsArray))
                ifExistChangeColorOfProfile();
                ifExistChangeColorOfVideo();

            }

        })

        showList2.addEventListener('click', function () {
            if (JSON.parse(localStorage.getItem('items-cute')) == null) {
                alert("Список пустой");
                return;
            }

            function urlSiteCrop(url) {
                let output = url.replace(/^/, `"`).replace(/$/, `",`);
                return output;
            };

            let itemsArray = JSON.parse(localStorage.getItem('items-cute'));

            let output = [];
            for (let i = 0; i < itemsArray.length; i++) {
                output[i] = urlSiteCrop(itemsArray[i]) + ("<br>");
            }

            let newWidnow = window.open();
            newWidnow.document.write(output.join(""));
            newWidnow.document.close();

        })

        deleteList2.addEventListener('click', function () {
            if (confirm("Подтвердить")) {
                localStorage.removeItem('items-cute')
            } else {
                return false;
            }
        })
    }





    function DelBoxes() {
        let alllinks = document.querySelectorAll(`.pcVideoListItem .usernameWrap a`);
        let linksinclude = [];
        let items = JSON.parse(localStorage.getItem('items'));
        let items_later = JSON.parse(localStorage.getItem('items-later'));
        let items_cute = JSON.parse(localStorage.getItem('items-cute'));

        for (let i = 0; i < alllinks.length; i++) {

            if (items != null) {
                if (items.includes(alllinks[i].href)) {
                    linksinclude.push(alllinks[i]);
                }
            }
            if (items_later != null) {
                if (items_later.includes(alllinks[i].href)) {
                    linksinclude.push(alllinks[i]);
                }
            }
            if (items_cute != null) {
                if (items_cute.includes(alllinks[i].href)) {
                    linksinclude.push(alllinks[i]);
                }
            }
        }
        linksinclude.forEach(e => e.closest("li").remove());
    }

    function waitForElm(selector) {
        return new Promise(resolve => {
            if (document.querySelector(selector)) {
                return resolve(document.querySelector(selector));
            }

            const observer = new MutationObserver(mutations => {
                if (document.querySelector(selector)) {
                    resolve(document.querySelector(selector));
                    observer.disconnect();
                }
            });

            observer.observe(document.body, {
                childList: true,
                subtree: true
            });
        });
    }

    function isExistAqua(elem){
        waitForElm(elem).then((span) => {
            span.style.color="#00ff6f";
        });
    }

    function ifExistChangeColorOfVideo() {
        let userInfo = document.querySelector(".userInfo .usernameBadgesWrapper a");
        if (userInfo == null) return;

        let isItemsIncludes = localStorage.getItem('items') ? JSON.parse(localStorage.getItem('items')).includes(userInfo.href) : false;
        let isItemLaterIncludes = localStorage.getItem('items-later') ? JSON.parse(localStorage.getItem('items-later')).includes(userInfo.href) : false;
        let isCuteIncludes = localStorage.getItem('items-cute') ? JSON.parse(localStorage.getItem('items-cute')).includes(userInfo.href) : false;

        if (isItemsIncludes) {
            let H1 = document.querySelector(".inlineFree");
            H1.style.color = "red";
            isExistAqua("#local_1");
        }

        if (isItemLaterIncludes) {
            let H1 = document.querySelector(".inlineFree");
            H1.style.color = "red";
            isExistAqua("#local_2");
        }

        if (isCuteIncludes) {
            let H1 = document.querySelector(".inlineFree");
            H1.style.color = "red";
            isExistAqua("#local_3");
        }
    }

    function ifExistChangeColorOfProfile() {
        let profile = document.querySelector("#profileHome a");
        if (profile == null) return;


        let isItemsIncludes = localStorage.getItem('items') ? JSON.parse(localStorage.getItem('items')).includes(profile.href) : false;
        let isItemLaterIncludes = localStorage.getItem('items-later') ? JSON.parse(localStorage.getItem('items-later')).includes(profile.href) : false;
        let isCuteIncludes = localStorage.getItem('items-cute') ? JSON.parse(localStorage.getItem('items-cute')).includes(profile.href) : false;

        if (isItemsIncludes) {
            let H1 = document.querySelector(".nameSubscribe h1");
            H1.style.color = "red";
            isExistAqua("#local_1");
        }

        if (isItemLaterIncludes) {
            let H1 = document.querySelector(".nameSubscribe h1");
            H1.style.color = "red";
            isExistAqua("#local_2");
        }

        if (isCuteIncludes) {
            let H1 = document.querySelector(".nameSubscribe h1");
            H1.style.color = "red";
            isExistAqua("#local_3");
        }
    }

    function HandleKeyBoardClick() {
        document.addEventListener('keydown', function (e) {
            if (event.ctrlKey && e.keyCode == '66') {
                document.getElementById("addToList").click();
            }
        });
    }



    CreateContainerforAllButtons();
    CreateFirstColumnButtons();
    CreateSecondColumnButtons();
    CreateThirdColumnButtons();
    DelBoxes();
    ifExistChangeColorOfProfile();
    ifExistChangeColorOfVideo();
    HandleKeyBoardClick();









})();