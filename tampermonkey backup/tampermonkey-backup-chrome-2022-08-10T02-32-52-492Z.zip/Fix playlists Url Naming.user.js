// ==UserScript==
// @name         Fix playlists Url Naming
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://rt.pornhub.com/users/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=pornhub.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';




if (window.location.href.includes("playlists")) {
    let pathname = window.location.pathname;
    document.querySelectorAll(".section_header.separated.first a").forEach(e => {e.href = `${pathname}/public`});
}




})();